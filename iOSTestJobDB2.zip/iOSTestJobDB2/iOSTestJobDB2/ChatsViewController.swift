//
//  ChatsViewController.swift
//  iOSTestJobDB2
//
//  Created by Oleksandr Yakobshe on 27.06.17.
//  Copyright © 2017 Oleksandr Yakobshe. All rights reserved.
//

import UIKit

class ChatsViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var navigationBar: UINavigationItem!
    @IBOutlet weak var navigationBarMain: UINavigationBar!
    
    var segmentControl: UISegmentedControl!
    let items = ["Chat", "Live Chat"]
    //var unreadMessages = 0
    
    var dataFromJson: [String: AnyObject] = [:]
    var channels: [AnyObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tableView.dataSource = self
        tableView.delegate = self
        
        //tableView.register(ChatCell.self, forCellReuseIdentifier: "ChatCell")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        installSegmentController()
        getSomeData()
    }
    
    func installSegmentController() {
        segmentControl = UISegmentedControl(frame: CGRect(x: 0, y: 44, width: self.view.layer.bounds.width, height: 44))
        segmentControl = UISegmentedControl(items: items)
        segmentControl.selectedSegmentIndex = 0
        segmentControl.layer.cornerRadius = 22
        navigationBar.titleView = segmentControl
    }

    func getSomeData() {
        let url = URL(string: "http://ec2-34-211-67-136.us-west-2.compute.amazonaws.com/api/chat/channels/")
        URLSession.shared.dataTask(with: url!, completionHandler: {
            (data, response, error) in
            if(error != nil){
                print("error")
            } else {
                do {
                    let json = try JSONSerialization.jsonObject(with: data!, options:.allowFragments) as! [String : AnyObject]
                    if let jsonChannels = json["channels"] {
                        self.channels = jsonChannels as! [AnyObject]
                    }
                    
                    OperationQueue.main.addOperation({
                        print(self.dataFromJson)
                        self.tableView.reloadData()
                    })
                    
                } catch {
                    print(error)
                }
            }
        }).resume()
    }
    
    func getDataFromURL(url: String) -> Data? {
        var data = Data()
        if let url = URL(string: url) {
            do {
                data = try Data(contentsOf: url)
            } catch {
                print(error)
            }
        }
        return data
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let tableViewCell = sender as! ChatCell
        if let indexPath = tableView.indexPath(for: tableViewCell) {
            print(indexPath.row)
            let destination = segue.destination as! ChatViewController
            destination.title = tableViewCell.personNameLabel.text!
            destination.userID = tableViewCell.userID
            if let image = tableViewCell.personImage.image {
                destination.imageUser = image
            }
        }
        
    }
    
}

extension ChatsViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return channels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChatCell", for: indexPath) as! ChatCell
        cell.selectionStyle = .none
        
        //cell.openChatButton.addTarget(self, action: #selector(openIndexPath), for: .touchUpInside)
        
        if let rowData = channels[indexPath.row] as? [String: AnyObject] {
            
            if let messagesUnread = rowData["unread_messages_count"] as? Int {
                print(messagesUnread)
                if messagesUnread != 0 {
                    cell.unreadedLable.text! = String(messagesUnread)
                    //unreadMessages += messagesUnread
                } else {
                    cell.unreadedLable.backgroundColor = UIColor.clear
                }
            }
            
            if let usersInChat = rowData["users"] as? [AnyObject] {
                if let notOurUser = usersInChat.first as? [String: AnyObject] {
                    if let userID = notOurUser["id"] as? Int {
                        cell.userID = userID
                    }
                }
            }
            
            if let lastMessageData = rowData["last_message"] as? [String: AnyObject] {
                
                if let lastMessage = lastMessageData["text"] as? String {
                    cell.personLastMessageLabel.text! = lastMessage
                }
                
                if let stringDate = lastMessageData["create_date"] as? String {
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
                    if let date = dateFormatter.date(from: stringDate) {
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "dd MMM HH:mm"
                        let lastDate = dateFormatter.string(from: date)
                        cell.lastDateMessageLabel.text! = lastDate
                    }
                }
                
                
                
                if let userData = lastMessageData["sender"] as? [String: AnyObject] {
                    var fullName = ""
                    if let firstName = userData["first_name"] as? String {
                        fullName += firstName
                    }
                    
                    if let lastName = userData["last_name"] as? String {
                        fullName += " " + lastName
                    }
                    cell.personNameLabel.text! = fullName
                    DispatchQueue.global(qos: .background).async {
                        if let data = self.getDataFromURL(url: userData["photo"] as! String) {
                            if let image = UIImage(data: data) {
                                DispatchQueue.main.async {
                                    cell.personImage.image = image
                                }
                            }
                        }
                    }
                }
            }
        }
        
        
        return cell
    }
    
}

extension ChatsViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let remove = UITableViewRowAction(style: .normal, title: "Remove") { action, index in
            self.channels.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
        remove.backgroundColor = UIColor.blue
        return [remove]
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 74
    }
    
}
