//
//  ChatCell.swift
//  iOSTestJobDB2
//
//  Created by Oleksandr Yakobshe on 27.06.17.
//  Copyright © 2017 Oleksandr Yakobshe. All rights reserved.
//

import UIKit

class ChatCell: UITableViewCell {

    @IBOutlet weak var personImage: UIImageView!
    @IBOutlet weak var personNameLabel: UILabel!
    @IBOutlet weak var personLastMessageLabel: UILabel!
    @IBOutlet weak var lastDateMessageLabel: UILabel!
    @IBOutlet weak var unreadedLable: UILabel!
    
    var userID = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        unreadedLable.layer.cornerRadius = 11
        personImage.layer.cornerRadius = 29
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
