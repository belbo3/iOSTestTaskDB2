//
//  ChatViewController.swift
//  iOSTestJobDB2
//
//  Created by Oleksandr Yakobshe on 28.06.17.
//  Copyright © 2017 Oleksandr Yakobshe. All rights reserved.
//

import UIKit

class ChatViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var messages: [AnyObject] = []
    var imageUser = UIImage()
    var userID = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(ChatMessageCell.self, forCellReuseIdentifier: "ChatMessageCell")
        let nib = UINib(nibName: "ChatMessageCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "ChatMessageCell")
        
        tableView.register(ChatFromMessageCell.self, forCellReuseIdentifier: "ChatFromMessageCell")
        let nibMessageFrom = UINib(nibName: "ChatFromMessageCell", bundle: nil)
        tableView.register(nibMessageFrom, forCellReuseIdentifier: "ChatFromMessageCell")
    }

    override func viewDidAppear(_ animated: Bool) {
        getSomeData()
    }

    func getSomeData() {
        let url = URL(string: "http://ec2-34-211-67-136.us-west-2.compute.amazonaws.com/api/chat/channels/1/messages/")
        URLSession.shared.dataTask(with: url!, completionHandler: {
            (data, response, error) in
            if(error != nil){
                print("error")
            } else {
                do {
                    let json = try JSONSerialization.jsonObject(with: data!, options:.allowFragments) as! [String : AnyObject]
                    if let jsonChannels = json["messages"] {
                        self.messages = (jsonChannels as! [AnyObject]).reversed()
                    }
                    
                    OperationQueue.main.addOperation({
                        print(self.messages)
                        self.tableView.reloadData()
                        let indexPath = IndexPath(row: self.messages.count - 1, section: 0)
                        
                        self.tableView.scrollToRow(at: indexPath, at: UITableViewScrollPosition.bottom, animated: true)
                    })
                    
                } catch {
                    print(error)
                }
            }
        }).resume()
    }
    
}

extension ChatViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var userID = 0
        
        let rowData = messages[indexPath.row] as? [String: AnyObject]
        
        if rowData != nil {
        
            if let senderInfo = rowData!["sender"] as? [String: AnyObject] {
                
                if let senderID = senderInfo["id"] as? Int {
                    
                    userID = senderID
                    
                }
                
            }
            
        }
        
        switch userID {
        case self.userID:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChatMessageCell", for: indexPath) as! ChatMessageCell
            cell.selectionStyle = .none
            cell.backgroundColor = UIColor.clear
            
            cell.userImage.image = imageUser
            
            if rowData != nil {
                if let message = rowData!["text"] as? String {
                    cell.messageLabel.text! = message
                }
                
                if let stringDate = rowData!["create_date"] as? String {
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
                    if let date = dateFormatter.date(from: stringDate) {
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "HH:mm"
                        let lastDate = dateFormatter.string(from: date)
                        cell.messageDate.text! = lastDate
                    }
                }
            }
            
            return cell
        default:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChatFromMessageCell", for: indexPath) as! ChatFromMessageCell
            cell.selectionStyle = .none
            cell.backgroundColor = UIColor.clear
            
            if rowData != nil {
                if let message = rowData!["text"] as? String {
                    cell.messageLabel.text! = message
                }
                
                if let stringDate = rowData!["create_date"] as? String {
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
                    if let date = dateFormatter.date(from: stringDate) {
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "HH:mm"
                        let lastDate = dateFormatter.string(from: date)
                        cell.messageDate.text! = lastDate
                    }
                }
            }
            
            return cell
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 44
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let width = self.tableView.layer.bounds.width
        
        let footer = UIView(frame: CGRect(x: 0, y: 44, width: width, height: 44))
        
        let textField = UITextField(frame: CGRect(x: 10, y: 0, width: width - 64, height: 44))
        textField.placeholder = "Message..."
        footer.addSubview(textField)
        
        let button = UIButton(frame: CGRect(x: width - 54, y: 0, width: 44, height: 44))
        button.setImage(UIImage(named: "camera"), for: .normal)
        footer.addSubview(button)
        
        footer.backgroundColor = UIColor.white
        
        return footer
    }
    
}

extension ChatViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
}
