//
//  TabBarViewController.swift
//  iOSTestJobDB2
//
//  Created by Oleksandr Yakobshe on 27.06.17.
//  Copyright © 2017 Oleksandr Yakobshe. All rights reserved.
//

import UIKit

class TabBarViewController: UITabBarController {

    //let items = ["Chat", "Live Chat"]
    
    @IBOutlet weak var navigationBar: UINavigationItem!
    var segmentView: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    /*override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let height: CGFloat = 50 //whatever height you want
        let bounds = self.navigationController!.navigationBar.bounds
        self.navigationController?.navigationBar.frame = CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height + height)
        
    }*/

}
